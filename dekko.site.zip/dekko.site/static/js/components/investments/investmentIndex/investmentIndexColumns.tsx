export const InvestmentIndexColumns = [
  {
    Header: "Investment",
    accessor: "investmentId",
    width: "135px",
    sortable: true,
  },
  {
    Header: "Investment Name",
    accessor: "investmentName",
    width: "295px",
    sortable: true,
  },
  /* {
     Header: "Nickname",
     accessor: "nickname",
     width: "150px",
     sortable: true,
   },
     {
       Header: "Office",
       accessor: "partnerOffice",
       width: "150px",
       sortable: true,
     },
     {
       Header: "Active",
       accessor: "isActive",
       width: "80px",
     },*/
  /*  {
    Header: "Delete",
    accessor: "delete",
    width: "50px",
  },*/
];
